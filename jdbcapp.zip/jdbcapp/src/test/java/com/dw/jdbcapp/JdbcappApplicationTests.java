package com.dw.jdbcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcappApplicationTests {

	@Test
	void contextLoads() {
	}

}
